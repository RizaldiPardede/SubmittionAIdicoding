package com.example.submissionpertamaai.DataStore

data class UserViewModel(
    val name: String,
    val userId: String,
    val token: String
)
